
package proyectosistemasoperativos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.util.ArrayList;

class Persona {
    String nombre;
    int edad;
    String ciudad;

    public Persona(String nombre, int edad, String ciudad) {
        this.nombre = nombre;
        this.edad = edad;
        this.ciudad = ciudad;
    }

    @Override
    public String toString() {
        return nombre + "," + edad + "," + ciudad;
    }
}

public class Tabla {
    static String archivo = "tabla_datos.csv";

    // Leer los datos desde el archivo CSV con validaciones y manejo de excepciones
    public static ArrayList<Persona> leerTabla() {
        ArrayList<Persona> tabla = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                // Validar si la línea no está vacía
                if (!linea.trim().isEmpty()) {
                    String[] datos = linea.split(",");
                    if (datos.length == 3) { // Validar que haya 3 elementos
                        try {
                            int edad = Integer.parseInt(datos[1]); // Intentar convertir la edad
                            tabla.add(new Persona(datos[0], edad, datos[2]));
                        } catch (NumberFormatException e) {
                            System.out.println("⚠️ Error al convertir la edad (no es un número válido): " + datos[1]);
                        }
                    } else {
                        System.out.println("⚠️ Línea mal formateada (menos de 3 elementos): " + linea);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("⚠️ Error al leer el archivo.");
            e.printStackTrace();
        }
        return tabla;
    }

    // Mostrar los datos en una ventana con JTable
    public static void mostrarTabla(ArrayList<Persona> tabla) {
        // Crear ventana
        JFrame frame = new JFrame("Tabla de Datos");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear modelo de tabla
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Nombre");
        model.addColumn("Edad");
        model.addColumn("Ciudad");

        // Agregar datos a la tabla
        for (Persona p : tabla) {
            model.addRow(new Object[]{p.nombre, p.edad, p.ciudad});
        }

        // Crear la tabla con el modelo
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane);

        // Mostrar ventana
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        // Leer datos guardados en CSV
        ArrayList<Persona> tabla = leerTabla();

        // Mostrar los datos en una tabla
        mostrarTabla(tabla);
    }
}

