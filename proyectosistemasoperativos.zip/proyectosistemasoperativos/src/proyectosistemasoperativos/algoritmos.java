
package proyectosistemasoperativos;

import java.awt.*;
import javax.swing.*;

public class algoritmos extends JFrame {
  public algoritmos() {
        setTitle("Menú de Algoritmos");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());

        // Panel de fondo con degradado
        JPanel panelFondo = crearPanelFondo();
        setContentPane(panelFondo);
        panelFondo.setLayout(new GridBagLayout());

        // Configuración de GridBagLayout
        GridBagConstraints config = new GridBagConstraints();
        config.insets = new Insets(10, 10, 10, 10);
        config.gridx = 0;
        config.fill = GridBagConstraints.HORIZONTAL;

        // Opciones del menú
        String[] opciones = {"Ordenamiento", "Búsqueda", "Recursión", "Grafos", "Salir"};

        // Agregar botones
        for (int i = 0; i < opciones.length; i++) {
            JButton boton = crearBoton(opciones[i]);
            config.gridy = i + 1;
            panelFondo.add(boton, config);

            // ActionListener para los botones
            final int opcion = i;
            boton.addActionListener(e -> {
                switch (opcion) {
                    case 0:
                        JOptionPane.showMessageDialog(this, "Abrir módulo de Ordenamiento");
                        break;
                    case 1:
                        JOptionPane.showMessageDialog(this, "Abrir módulo de Búsqueda");
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(this, "Abrir módulo de Recursión");
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(this, "Abrir módulo de Grafos");
                        break;
                    case 4:
                        mostrarAnimacionSalida();
                        break;
                }
            });
        }

        setVisible(true);
    }

    // Método para crear el panel de fondo con degradado
    private JPanel crearPanelFondo() {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;

                // Degradado de fondo de azul cielo a lila
                GradientPaint gradiente = new GradientPaint(0, 0, new Color(135, 206, 250), 0, getHeight(), new Color(186, 85, 211));
                g2d.setPaint(gradiente);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
    }

    // Método para crear botones estilizados con degradado
    private JButton crearBoton(String texto) {
        JButton boton = new JButton(texto) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradienteBoton = new GradientPaint(0, 0, new Color(173, 216, 230), getWidth(), getHeight(), new Color(186, 85, 211));
                g2d.setPaint(gradienteBoton);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };

        boton.setFont(new Font("SansSerif", Font.BOLD, 20));
        boton.setForeground(Color.BLACK);
        boton.setOpaque(false);
        boton.setBorder(BorderFactory.createLineBorder(new Color(173, 216, 230), 3));
        boton.setPreferredSize(new Dimension(200, 40));
        boton.setHorizontalAlignment(SwingConstants.CENTER);

        return boton;
    }

    // Método para mostrar la animación antes de salir
    private void mostrarAnimacionSalida() {
        JFrame ventanaSalida = new JFrame("Hora de descansar");
        ventanaSalida.setSize(400, 400);
        ventanaSalida.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventanaSalida.setLocationRelativeTo(null);

        // Instancia de la clase PanelAnimado
        PanelAnimado panelAnimado = new PanelAnimado();
        ventanaSalida.add(panelAnimado, BorderLayout.CENTER);

        // Etiqueta con mensaje de despedida
        JLabel mensaje = new JLabel("Mucho trabajo por hoy, es hora de descansar <3", SwingConstants.CENTER);
        mensaje.setFont(new Font("SansSerif", Font.BOLD, 16));
        mensaje.setForeground(Color.WHITE);
        ventanaSalida.add(mensaje, BorderLayout.SOUTH);

        ventanaSalida.getContentPane().setBackground(new Color(50, 50, 100)); // Azul oscuro
        ventanaSalida.setVisible(true);

        // Iniciar la animación
        panelAnimado.animar();

        // Cerrar la aplicación después de 3 segundos
        new Thread(() -> {
            try {
                Thread.sleep(3000);
                System.exit(0);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    // Clase interna para la animación de la luna y estrellas
    private class PanelAnimado extends JPanel {
        private int lunaX = 150, lunaY = 50; // Posición inicial de la luna
        private int[] estrellasX = {50, 100, 200, 250, 300};
        private int[] estrellasY = {30, 60, 40, 80, 20};

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;

            // Fondo nocturno
            g2d.setColor(new Color(25, 25, 112)); // Azul noche
            g2d.fillRect(0, 0, getWidth(), getHeight());

            // Dibujar la luna (un círculo amarillo)
            g2d.setColor(Color.YELLOW);
            g2d.fillOval(lunaX, lunaY, 60, 60);

            // Dibujar estrellas
            g2d.setColor(Color.WHITE);
            for (int i = 0; i < estrellasX.length; i++) {
                g2d.fillOval(estrellasX[i], estrellasY[i], 10, 10);
            }
        }

        // Método para animar la luna y estrellas
        public void animar() {
            new Thread(() -> {
                for (int i = 0; i < 30; i++) {
                    lunaY += 2; // Movimiento hacia abajo
                    for (int j = 0; j < estrellasY.length; j++) {
                        estrellasY[j] += 1; // Movimiento sutil de estrellas
                    }
                    repaint();
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }

    public static void main(String[] args) {
        new algoritmos();
    }
}