
package proyectosistemasoperativos;
import javax.swing.*;
import java.awt.*;

public class Proyectosistemasoperativos {

    public static void main(String[] args) {
        // Creación de la ventana principal
        JFrame ventana = new JFrame("Sistemas Operativos");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(500, 600);
        ventana.setLayout(new GridBagLayout());

        // Panel de fondo con degradado de colores y figuras decorativas en los bordes
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;

                // Degradado de fondo
                GradientPaint gradiente = new GradientPaint(0, 0, new Color(135, 206, 250), 0, getHeight(), new Color(186, 85, 211));
                g2d.setPaint(gradiente);
                g2d.fillRect(0, 0, getWidth(), getHeight());

                // Dibujar círculos decorativos en los bordes
                g2d.setColor(new Color(255, 255, 255, 150)); // Blanco semi-transparente
                for (int i = 0; i < getWidth(); i += 50) {
                    g2d.fillOval(i, 0, 20, 20); // Superior
                    g2d.fillOval(i, getHeight() - 20, 20, 20); // Inferior
                }
                for (int j = 0; j < getHeight(); j += 50) {
                    g2d.fillOval(0, j, 20, 20); // Izquierda
                    g2d.fillOval(getWidth() - 20, j, 20, 20); // Derecha
                }
            }
        };
        panelFondo.setLayout(new GridBagLayout());
        ventana.setContentPane(panelFondo);

        GridBagConstraints config = new GridBagConstraints();
        config.insets = new Insets(10, 10, 10, 10);
        config.gridx = 0;
        config.fill = GridBagConstraints.HORIZONTAL;

        // Título principal de la interfaz
        JLabel etiquetaTitulo = new JLabel("SISTEMAS OPERATIVOS", SwingConstants.CENTER);
        etiquetaTitulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        etiquetaTitulo.setForeground(Color.WHITE);
        etiquetaTitulo.setOpaque(true);
        etiquetaTitulo.setBackground(new Color(70, 130, 180)); // Azul acero
        etiquetaTitulo.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2));
        config.gridy = 0;
        panelFondo.add(etiquetaTitulo, config);

        // Opciones del menú
        String[] opciones = {"1) Datos", "2) Algoritmo"};
        Color colorInicioBoton = new Color(173, 216, 230); // Azul cielo claro
        Color colorFinBoton = new Color(186, 85, 211); // Lila

        // Crear botones para las opciones
        for (int i = 0; i < opciones.length; i++) {
            JButton botonOpcion = new JButton(opciones[i]) {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2d = (Graphics2D) g;
                    GradientPaint gradienteBoton = new GradientPaint(0,0, new Color(173, 216, 230), getWidth(), getHeight(), new Color(186, 85, 211));
                    g2d.setPaint(gradienteBoton);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                    super.paintComponent(g);
                }
            };
            botonOpcion.setFont(new Font("SansSerif", Font.BOLD, 20));
            botonOpcion.setForeground(Color.BLACK);
            botonOpcion.setOpaque(false); // Esto es para que el botón no tenga un fondo opaco y se pueda pintar
            botonOpcion.setBorder(BorderFactory.createLineBorder(colorInicioBoton, 3));
            botonOpcion.setPreferredSize(new Dimension(200, 40));
            botonOpcion.setHorizontalAlignment(SwingConstants.CENTER);
            config.gridy = i + 1;
            panelFondo.add(botonOpcion, config);

            // ActionListener para los botones
            final int opcion = i + 1;
            botonOpcion.addActionListener(e -> {
                JOptionPane.showMessageDialog(ventana, "Opción seleccionada: " + opcion);
            });
        }

        // Botón de salida con color rojo
        JButton botonSalir = new JButton("3) Salir");
        botonSalir.setFont(new Font("SansSerif", Font.BOLD, 16));
        botonSalir.setBackground(new Color(255, 99, 71)); // Rojo tomate
        botonSalir.setForeground(Color.WHITE);
        botonSalir.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
        config.gridy = 4;
        panelFondo.add(botonSalir, config);

        // Acción de cerrar ventana
        botonSalir.addActionListener(e -> {
            ventana.dispose(); // Cierra la ventana 
        });

        ventana.setVisible(true);
    }
}